/**
 * @file StudentProfile.tsx
 * @description 学生端个人资料页：展示/编辑信息、统计打卡数据、快捷菜单、心理测评（含 mock 降级）、设置与退出登录
 * @module web-frontend/pages/student
 */
import { useState } from 'react';
import { useAuthStore } from '../../store/authStore';
import { useMoodStore } from '../../store/moodStore';
import { Header } from '../../components/common/Header';
import { Modal, Button } from '../../components/ui';
import { assessmentApi } from '../../services/api';
import { User, Settings, Bell, BookOpen, Calendar, Edit3, Check, LogOut, Mail, Phone, Globe, ClipboardList, Loader2, Smartphone, Download, QrCode } from 'lucide-react';
import { useToast } from '../../components/ui/Toast';

// 快捷菜单项：图标、标题、徽章数（可选）
const menuItems = [
  { icon: Bell, label: '通知中心', badge: 3 },
  { icon: BookOpen, label: '使用记录' },
  { icon: Calendar, label: '打卡日历' },
  { icon: Settings, label: '系统设置' },
];

// 设置项：图标、标题、描述
const settingsItems = [
  { icon: Bell, label: '消息通知', description: '接收系统通知和提醒' },
  { icon: Mail, label: '邮箱设置', description: '配置邮箱通知' },
  { icon: Globe, label: '语言设置', description: '简体中文' },
  { icon: Phone, label: '隐私设置', description: '管理数据隐私和权限' },
];

/**
 * 学生端个人资料组件
 * @returns JSX 元素
 */
export default function StudentProfile() {
  // 当前用户、更新资料、退出登录
  const user = useAuthStore((state) => state.user);
  const updateProfile = useAuthStore((state) => state.updateProfile);
  const logout = useAuthStore((state) => state.logout);
  // 心情历史与连续天数（用于统计展示）
  const moodHistory = useMoodStore((state) => state.moodHistory);
  const continuousDays = useMoodStore((state) => state.continuousDays);
  const toast = useToast();

  // 是否处于资料编辑态
  const [isEditing, setIsEditing] = useState(false);
  // 编辑中的昵称与签名
  const [editedNickname, setEditedNickname] = useState(user?.nickname || '');
  const [editedSignature, setEditedSignature] = useState(user?.signature || '');

  // 心理测评状态
  // 后端返回的题目结构兼容多种字段命名（text/question）
  interface FetchedQuestion {
    id: string;
    text?: string;
    question?: string;
    options: string[];
  }
  // 后端返回的结果结构兼容多种字段命名
  interface FetchedResult {
    result_id?: string;
    id?: string;
    total_score?: number;
    score?: number;
    risk_level?: string;
    level?: string;
    description?: string;
    suggestion?: string;
    suggestions?: string[];
  }
  // 测评弹窗是否打开
  const [assessmentOpen, setAssessmentOpen] = useState(false);
  // 测评标题
  const [assessmentTitle, setAssessmentTitle] = useState('情绪探索');
  // 题目列表
  const [assessmentQuestions, setAssessmentQuestions] = useState<FetchedQuestion[]>([]);
  // 各题目答案（题目ID -> 选项索引）
  const [assessmentAnswers, setAssessmentAnswers] = useState<Record<string, number>>({});
  // 测评结果
  const [assessmentResult, setAssessmentResult] = useState<FetchedResult | null>(null);
  // 测评加载中
  const [assessmentLoading, setAssessmentLoading] = useState(false);
  // 测评错误
  const [assessmentError, setAssessmentError] = useState<string | null>(null);
  // 数据来源：api 或 mock
  const [assessmentSource, setAssessmentSource] = useState<'api' | 'mock'>('mock');

  /**
   * 开始测评：打开弹窗，拉取题目，失败时降级 mock 题目
   */
  const startAssessment = async () => {
    setAssessmentOpen(true);
    setAssessmentLoading(true);
    setAssessmentError(null);
    setAssessmentResult(null);
    setAssessmentAnswers({});
    try {
      // 调用后端获取情绪测评题目
      const data = (await assessmentApi.getQuestions('mood')) as unknown as {
        title?: string;
        questions?: FetchedQuestion[];
      };
      const qs = data.questions || [];
      if (qs.length) {
        setAssessmentQuestions(qs);
        setAssessmentTitle(data.title || '情绪探索');
        setAssessmentSource('api');
      } else {
        throw new Error('无题目');
      }
    } catch {
      // 降级到 mock 题目
      setAssessmentSource('mock');
      setAssessmentTitle('情绪探索（示例）');
      setAssessmentQuestions([
        { id: 'q1', text: '最近两周，你感到心情低落、沮丧或绝望的频率是？', options: ['完全没有', '有几天', '超过一半的时间', '几乎每天'] },
        { id: 'q2', text: '最近两周，你对平时感兴趣的事情失去兴趣的频率是？', options: ['完全没有', '有几天', '超过一半的时间', '几乎每天'] },
        { id: 'q3', text: '最近两周，你感到入睡困难或睡眠过多的频率是？', options: ['完全没有', '有几天', '超过一半的时间', '几乎每天'] },
      ]);
    } finally {
      setAssessmentLoading(false);
    }
  };

  /**
   * 提交测评：校验全部作答后提交，并拉取结果，失败时降级 mock 结果
   */
  const submitAssessment = async () => {
    if (!user) return;
    // 校验：所有题目均已作答
    const answered = assessmentQuestions.every((q) => assessmentAnswers[q.id] !== undefined);
    if (!answered) {
      setAssessmentError('请完成所有题目后再提交');
      return;
    }
    setAssessmentLoading(true);
    setAssessmentError(null);
    // 将答案按题目顺序整理为数组
    const answers = assessmentQuestions.map((q) => assessmentAnswers[q.id]);
    try {
      // 提交答案获取结果ID
      const submitRes = (await assessmentApi.submit({
        userId: user.id,
        type: 'mood',
        answers,
      })) as unknown as { result_id?: string };
      const resultId = submitRes.result_id;
      if (resultId) {
        // 拉取结果详情
        const result = (await assessmentApi.getResult(resultId)) as unknown as FetchedResult;
        setAssessmentResult(result);
        setAssessmentSource('api');
      } else {
        throw new Error('未返回结果ID');
      }
    } catch {
      // 降级到 mock 结果：根据总分映射风险等级
      setAssessmentSource('mock');
      const total = answers.reduce((a, b) => a + b, 0);
      const level = total <= 2 ? 'green' : total <= 4 ? 'yellow' : total <= 6 ? 'orange' : 'red';
      setAssessmentResult({
        total_score: total,
        risk_level: level,
        description: '（示例结果）根据你的作答，小星为你生成了初步评估。',
        suggestions: ['继续每天的心情打卡', '试试呼吸练习保持放松', '和小星聊聊最近的感受'],
      });
    } finally {
      setAssessmentLoading(false);
    }
  };

  /**
   * 保存资料：调用鉴权 store 更新昵称与签名
   */
  const handleSave = async () => {
    await updateProfile({ nickname: editedNickname, signature: editedSignature });
    setIsEditing(false);
    toast.success('资料已更新');
  };

  // 统计：总打卡次数
  const totalCheckins = moodHistory.length;
  // 统计：平均心情（保留 1 位小数）
  const averageMood = moodHistory.length > 0
    ? (moodHistory.reduce((sum, m) => sum + m.moodLevel, 0) / moodHistory.length).toFixed(1)
    : '0';

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-indigo-50">
      <Header role="student" />
      
      <main id="main" className="pt-20 pb-8 px-4 max-w-4xl mx-auto">
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl p-6 mb-8 text-white shadow-xl">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
              <User className="w-10 h-10" />
            </div>
            <div className="flex-1">
              {isEditing ? (
                <div>
                  <input
                    type="text"
                    value={editedNickname}
                    onChange={(e) => setEditedNickname(e.target.value)}
                    className="bg-white/20 text-white border border-white/30 rounded-lg px-3 py-2 mb-2 w-full"
                    placeholder="昵称"
                  />
                  <textarea
                    value={editedSignature}
                    onChange={(e) => setEditedSignature(e.target.value)}
                    className="bg-white/20 text-white border border-white/30 rounded-lg px-3 py-2 w-full"
                    placeholder="个性签名"
                    rows={2}
                  />
                </div>
              ) : (
                <div>
                  <h2 className="text-2xl font-bold">{user?.nickname}</h2>
                  <p className="text-indigo-200 mt-1">{user?.signature || '暂无个性签名'}</p>
                </div>
              )}
              <div className="flex items-center gap-2 mt-3">
                {user?.ageGroup && <span className="px-3 py-1 bg-white/20 rounded-full text-sm">{user.ageGroup}</span>}
                <span className="px-3 py-1 bg-white/20 rounded-full text-sm">学生</span>
              </div>
            </div>
            <button
              onClick={isEditing ? handleSave : () => setIsEditing(true)}
              aria-label="编辑"
              className="p-3 bg-white/20 rounded-full hover:bg-white/30 transition-colors"
            >
              {isEditing ? <Check className="w-5 h-5" /> : <Edit3 className="w-5 h-5" />}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-2xl p-5 shadow-lg text-center">
            <p className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">{moodHistory.length === 0 ? '--' : totalCheckins}</p>
            <p className="text-sm text-gray-500 mt-1">总打卡次数</p>
          </div>
          <div className="bg-white rounded-2xl p-5 shadow-lg text-center">
            <p className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">{moodHistory.length === 0 ? '--' : averageMood}</p>
            <p className="text-sm text-gray-500 mt-1">平均心情</p>
          </div>
          <div className="bg-white rounded-2xl p-5 shadow-lg text-center">
            <p className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">{moodHistory.length === 0 ? '--' : continuousDays}</p>
            <p className="text-sm text-gray-500 mt-1">连续打卡</p>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-6 mb-8 shadow-lg">
          <h3 className="text-lg font-bold text-gray-800 mb-4">快捷菜单</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.label}
                  onClick={() => toast.info('功能开发中，敬请期待')}
                  aria-label={item.label}
                  className="flex flex-col items-center p-4 rounded-xl hover:bg-purple-50 transition-colors"
                >
                  <div className="relative">
                    <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-2">
                      <Icon className="w-6 h-6 text-purple-600" />
                    </div>
                    {item.badge && (
                      <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                        {item.badge}
                      </span>
                    )}
                  </div>
                  <span className="text-sm font-medium text-gray-700">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="bg-white rounded-3xl p-6 mb-8 shadow-lg">
          <h3 className="text-lg font-bold text-gray-800 mb-4">心理测评</h3>
          <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl">
            <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm">
              <ClipboardList className="w-6 h-6 text-purple-600" />
            </div>
            <div className="flex-1">
              <p className="font-bold text-gray-800">情绪探索测评</p>
              <p className="text-sm text-gray-500">了解最近的情绪状态，获取个性化建议</p>
            </div>
            <Button
              onClick={startAssessment}
              className="bg-gradient-to-r from-indigo-500 to-purple-600"
              size="sm"
            >
              开始测评
            </Button>
          </div>
        </div>

        {/* 下载 App 推荐 */}
        <div className="bg-white rounded-3xl p-6 mb-8 shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-primary-500 to-secondary-600 rounded-2xl p-5 sm:p-6 text-white relative overflow-hidden">
            <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-white/10 rounded-full"></div>
            <div className="absolute right-12 top-4 w-16 h-16 bg-white/10 rounded-full"></div>
            <div className="relative flex flex-col sm:flex-row items-center gap-5">
              <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center shadow-lg flex-shrink-0">
                <Smartphone className="w-10 h-10 text-primary-600" />
              </div>
              <div className="flex-1 text-center sm:text-left">
                <h3 className="text-xl font-bold flex items-center justify-center sm:justify-start gap-2">
                  <Download className="w-5 h-5" />
                  下载星屿 App
                </h3>
                <p className="text-primary-100 text-sm mt-1">
                  扫码下载移动端，随时随地记录心情、获取 AI 心理陪伴
                </p>
                <div className="flex flex-wrap gap-2 mt-3 justify-center sm:justify-start">
                  <span className="px-2.5 py-1 bg-white/20 rounded-full text-xs">心情打卡</span>
                  <span className="px-2.5 py-1 bg-white/20 rounded-full text-xs">AI 心理陪伴</span>
                  <span className="px-2.5 py-1 bg-white/20 rounded-full text-xs">树人互助</span>
                </div>
              </div>
              <div className="flex flex-col items-center flex-shrink-0">
                <div className="w-24 h-24 bg-white rounded-xl p-2 shadow-lg">
                  {/* 简易二维码占位图案 */}
                  <svg viewBox="0 0 100 100" className="w-full h-full">
                    <rect width="100" height="100" fill="white" />
                    {Array.from({ length: 49 }).map((_, i) => {
                      const row = Math.floor(i / 7);
                      const col = i % 7;
                      const seed = (row * 7 + col * 13 + row * col) % 3;
                      if (seed === 0) {
                        return (
                          <rect
                            key={i}
                            x={col * 14 + 2}
                            y={row * 14 + 2}
                            width="10"
                            height="10"
                            fill="#1f2937"
                          />
                        );
                      }
                      return null;
                    })}
                    {/* 三个定位角 */}
                    <rect x="2" y="2" width="20" height="20" fill="none" stroke="#1f2937" strokeWidth="4" />
                    <rect x="6" y="6" width="12" height="12" fill="#1f2937" />
                    <rect x="78" y="2" width="20" height="20" fill="none" stroke="#1f2937" strokeWidth="4" />
                    <rect x="82" y="6" width="12" height="12" fill="#1f2937" />
                    <rect x="2" y="78" width="20" height="20" fill="none" stroke="#1f2937" strokeWidth="4" />
                    <rect x="6" y="82" width="12" height="12" fill="#1f2937" />
                  </svg>
                </div>
                <p className="text-xs text-primary-100 mt-1.5 flex items-center gap-1">
                  <QrCode className="w-3 h-3" /> 扫码下载
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-6 mb-8 shadow-lg">
          <h3 className="text-lg font-bold text-gray-800 mb-4">设置</h3>
          <div className="space-y-3">
            {settingsItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.label}
                  onClick={() => toast.info('功能开发中，敬请期待')}
                  aria-label={item.label}
                  className="w-full flex items-center gap-4 p-4 rounded-xl hover:bg-gray-50 transition-colors text-left"
                >
                  <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                    <Icon className="w-5 h-5 text-gray-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-800">{item.label}</p>
                    <p className="text-sm text-gray-500">{item.description}</p>
                  </div>
                  <span className="text-gray-400">›</span>
                </button>
              );
            })}
          </div>
        </div>

        <button
          onClick={() => {
            logout();
          }}
          className="w-full py-4 bg-red-50 text-red-600 rounded-2xl font-bold hover:bg-red-100 transition-colors flex items-center justify-center gap-2"
        >
          <LogOut className="w-5 h-5" />
          退出登录
        </button>

        <Modal
          isOpen={assessmentOpen}
          onClose={() => !assessmentLoading && setAssessmentOpen(false)}
          title={assessmentTitle}
          size="lg"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className={`text-xs px-2 py-0.5 rounded-full ${assessmentSource === 'api' ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-500'}`}>
                {assessmentSource === 'api' ? 'API 数据' : '示例数据'}
              </span>
            </div>

            {assessmentLoading && (
              <div className="flex items-center justify-center py-8 text-gray-400">
                <Loader2 className="w-6 h-6 animate-spin mr-2" />
                加载中...
              </div>
            )}

            {!assessmentLoading && !assessmentResult && (
              <>
                <div className="space-y-5 max-h-[50vh] overflow-y-auto pr-1">
                  {assessmentQuestions.map((q, idx) => (
                    <div key={q.id}>
                      <p className="font-medium text-gray-800 mb-2">
                        {idx + 1}. {q.text || q.question}
                      </p>
                      <div className="space-y-2">
                        {q.options.map((opt, oi) => (
                          <button
                            key={oi}
                            role="radio"
                            aria-checked={assessmentAnswers[q.id] === oi}
                            onClick={() => setAssessmentAnswers((prev) => ({ ...prev, [q.id]: oi }))}
                            className={`w-full text-left px-4 py-2.5 rounded-xl border-2 transition-all duration-fast ${
                              assessmentAnswers[q.id] === oi
                                ? 'border-purple-500 bg-purple-50 text-purple-700'
                                : 'border-gray-200 hover:border-purple-200 text-gray-700'
                            }`}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
                {assessmentError && (
                  <p className="text-sm text-danger-600">{assessmentError}</p>
                )}
                <Button
                  onClick={submitAssessment}
                  className="w-full bg-gradient-to-r from-indigo-500 to-purple-600"
                >
                  提交测评
                </Button>
              </>
            )}

            {!assessmentLoading && assessmentResult && (
              <div className="space-y-4">
                <div className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-500">测评得分</span>
                    <span className="text-2xl font-bold text-purple-600">
                      {assessmentResult.total_score ?? assessmentResult.score ?? 0}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">风险等级</span>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                      (assessmentResult.risk_level || assessmentResult.level) === 'green' ? 'bg-green-100 text-green-600' :
                      (assessmentResult.risk_level || assessmentResult.level) === 'yellow' ? 'bg-yellow-100 text-yellow-600' :
                      (assessmentResult.risk_level || assessmentResult.level) === 'red' ? 'bg-red-100 text-red-600' :
                      'bg-orange-100 text-orange-600'
                    }`}>
                      {(assessmentResult.risk_level || assessmentResult.level || 'green') === 'green' ? '正常' :
                      (assessmentResult.risk_level || assessmentResult.level) === 'yellow' ? '低风险' :
                      (assessmentResult.risk_level || assessmentResult.level) === 'red' ? '高风险' :
                      '中风险'}
                    </span>
                  </div>
                </div>
                {assessmentResult.description && (
                  <p className="text-sm text-gray-600">{assessmentResult.description}</p>
                )}
                {assessmentResult.suggestions && assessmentResult.suggestions.length > 0 && (
                  <div>
                    <p className="text-sm font-medium text-gray-800 mb-2">建议</p>
                    <ul className="space-y-1.5">
                      {assessmentResult.suggestions.map((s, i) => (
                        <li key={i} className="text-sm text-gray-600 flex items-start gap-2">
                          <Check className="w-4 h-4 text-purple-500 mt-0.5 flex-shrink-0" />
                          {s}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                <Button
                  onClick={() => setAssessmentOpen(false)}
                  className="w-full bg-gradient-to-r from-indigo-500 to-purple-600"
                >
                  完成
                </Button>
              </div>
            )}
          </div>
        </Modal>
      </main>
    </div>
  );
}