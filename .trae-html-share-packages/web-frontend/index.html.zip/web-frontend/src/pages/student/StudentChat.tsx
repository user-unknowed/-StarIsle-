/**
 * @file StudentChat.tsx
 * @description 学生端 AI 心理咨询助手对话页，支持历史消息加载、话题选择、风险信号提示
 * @module web-frontend/pages/student
 */
import { useEffect, useRef, useState } from 'react';
import { useAuthStore } from '../../store/authStore';
import { useChatStore } from '../../store/chatStore';
import { Header } from '../../components/common/Header';
import { Send, Sparkles, AlertTriangle, Loader2 } from 'lucide-react';
import { EmergencyHelpButton } from '../../components/common/EmergencyHelpButton';
import { AI_CHAT_ENABLED } from '../../config/features';
import { ChatDisabledPlaceholder } from '../../components/common/ChatDisabledPlaceholder';

/**
 * 学生端 AI 心理咨询助手对话组件
 * @returns JSX 元素（功能关闭时返回禁用占位组件）
 */
export default function StudentChat() {
  // AI 聊天功能未开启时直接展示禁用占位
  if (!AI_CHAT_ENABLED) {
    return <ChatDisabledPlaceholder role="student" />;
  }

  // 当前登录用户
  const user = useAuthStore((state) => state.user);
  // 从聊天 store 取出消息列表、话题、输入态及 action
  const {
    messages,
    topics,
    isTyping,
    inputValue,
    isUsingMockData,
    fetchMessages,
    sendMessage,
    selectTopic,
    setInputValue,
  } = useChatStore();

  // 消息列表底部锚点，用于自动滚动
  const messagesEndRef = useRef<HTMLDivElement>(null);
  // 是否正在加载历史消息
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);

  // 进入页面拉取历史消息（避免组件卸载后 setState，使用 cancelled 标志）
  useEffect(() => {
    if (user) {
      let cancelled = false;
      setIsLoadingMessages(true);
      fetchMessages(user.id).finally(() => {
        if (!cancelled) setIsLoadingMessages(false);
      });
      return () => {
        cancelled = true;
      };
    }
  }, [user, fetchMessages]);

  // 消息列表变化时自动滚动到底部
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  /**
   * 发送消息：非空且已登录时调用 store 发送
   */
  const handleSend = async () => {
    if (inputValue.trim() && user) {
      await sendMessage(user.id, inputValue.trim());
    }
  };

  /**
   * 输入框按键事件：Enter 发送，Shift+Enter 换行
   * @param e - 键盘事件
   */
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-indigo-50">
      <Header role="student" />
      <EmergencyHelpButton />

      <main className="pt-20 pb-8 px-4 max-w-4xl mx-auto">
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden h-[calc(100vh-8rem)] flex flex-col">
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-5 text-white">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-lg font-bold">小星</h2>
                <p className="text-sm text-indigo-200">AI心理咨询助手</p>
              </div>
            </div>
          </div>

          {isUsingMockData && (
            <div className="bg-warning-50 border-b border-warning-200 px-4 py-2 text-sm text-warning-700 text-center">后端未连接，当前为示例回复</div>
          )}

          {isLoadingMessages && (
            <div className="flex-1 flex items-center justify-center">
              <Loader2 className="w-8 h-8 animate-spin text-primary-500" />
            </div>
          )}

          {!isLoadingMessages && messages.length === 0 && (
            <div className="flex-1 flex flex-col items-center justify-center p-8">
              <div className="w-24 h-24 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center mb-6">
                <Sparkles className="w-12 h-12 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">你好呀！我是小星</h3>
              <p className="text-gray-500 text-center mb-8">有什么想聊的吗？我在这里听你说。</p>

              <div className="w-full max-w-md">
                <p className="text-sm text-gray-600 mb-3">试试这些话题：</p>
                <div className="grid grid-cols-2 gap-3">
                  {topics.map((topic) => (
                    <button
                      key={topic.id}
                      onClick={() => selectTopic(topic)}
                      aria-label={topic.title}
                      className="text-left p-3 bg-gray-50 hover:bg-purple-50 rounded-xl transition-colors border border-gray-100"
                    >
                      <span className="text-xs text-purple-500 mb-1 block">{topic.category}</span>
                      <span className="text-sm text-gray-700 font-medium">{topic.title}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {!isLoadingMessages && messages.length > 0 && (
            <div className="flex-1 overflow-y-auto p-6 space-y-4" role="log" aria-live="polite">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[80%] ${message.role === 'user' ? 'order-2' : 'order-1'}`}>
                    <div className="flex items-center gap-2 mb-1">
                      {message.role === 'assistant' && (
                        <span className="text-xs text-gray-500">小星</span>
                      )}
                      {message.role === 'user' && (
                        <span className="text-xs text-gray-500">{user?.nickname}</span>
                      )}
                    </div>
                    <div
                      className={`px-4 py-3 rounded-2xl ${
                        message.role === 'user'
                          ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-br-md'
                          : 'bg-gray-100 text-gray-800 rounded-bl-md'
                      }`}
                    >
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                      {message.role === 'assistant' && (message.riskLevel === 'red' || message.riskLevel === 'orange') && (
                        <div className={`mt-2 p-2 rounded-xl flex items-center gap-2 ${message.riskLevel === 'red' ? 'bg-red-50 border border-red-200' : 'bg-orange-50 border border-orange-200'}`}>
                          <AlertTriangle className="w-4 h-4 flex-shrink-0 text-red-500" />
                          <p className="text-xs text-red-600 font-medium">
                            检测到风险信号，请点击右下角紧急帮助按钮获取支持
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className={`w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center ${message.role === 'user' ? 'order-1 ml-2' : 'order-2 mr-2'}`}>
                    {message.role === 'user' ? (
                      <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center">
                        <span className="text-sm font-medium">{user?.nickname?.[0]}</span>
                      </div>
                    ) : (
                      <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center">
                        <Sparkles className="w-5 h-5 text-white" />
                      </div>
                    )}
                  </div>
                </div>
              ))}
              
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 px-4 py-3 rounded-2xl rounded-bl-md">
                    <div className="flex items-center gap-1">
                      <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></span>
                      <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
                      <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></span>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
          )}

          <div className="p-4 border-t border-gray-100">
            <div className="flex items-end gap-3">
              <div className="flex-1 relative">
                <textarea
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="输入你想说的话..."
                  rows={1}
                  aria-label="输入消息"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                  style={{ minHeight: '48px', maxHeight: '120px' }}
                />
              </div>
              <button
                onClick={handleSend}
                aria-label="发送"
                disabled={!inputValue.trim()}
                className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${
                  inputValue.trim()
                    ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white hover:shadow-lg'
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}