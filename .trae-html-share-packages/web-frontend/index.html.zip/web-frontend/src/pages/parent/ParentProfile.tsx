/**
 * @file ParentProfile.tsx
 * @description 家长端个人资料页：展示/编辑个人信息、绑定概览、通知与隐私设置、退出登录
 * @module web-frontend/pages/parent
 */
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useParentStore } from '../../store/parentStore';
import { useAuthStore } from '../../store/authStore';
import { Header } from '../../components/common/Header';
import { useToast } from '../../components/ui';
import {
  User,
  Settings,
  Bell,
  LogOut,
  Mail,
  Phone,
  Globe,
  Shield,
  Edit3,
  Check,
  AlertCircle,
  Smartphone,
  Download,
  QrCode,
} from 'lucide-react';

// 设置项配置：图标、标题、描述、是否默认开启
const settingsItems = [
  { icon: Bell, label: '告警通知', description: '接收孩子紧急告警推送', defaultOn: true },
  { icon: Mail, label: '邮箱通知', description: '每周接收孩子状态报告' },
  { icon: Shield, label: '隐私设置', description: '管理数据访问与授权' },
  { icon: Globe, label: '语言设置', description: '简体中文' },
];

/**
 * 家长端个人资料组件
 * @returns JSX 元素
 */
export default function ParentProfile() {
  const navigate = useNavigate();
  // 家长 store：个人资料、孩子列表、告警及加载状态
  const { parentProfile, children, emergencyAlerts, isLoading, error, isUsingMockData, fetchProfile, fetchChildren, fetchAlerts } = useParentStore();
  // 鉴权 store：当前用户、退出登录、更新资料
  const user = useAuthStore((state) => state.user);
  const logout = useAuthStore((state) => state.logout);
  const updateProfile = useAuthStore((state) => state.updateProfile);
  const toast = useToast();

  // 是否处于资料编辑态
  const [isEditing, setIsEditing] = useState(false);
  // 编辑中的昵称与签名
  const [editedNickname, setEditedNickname] = useState(parentProfile?.nickname || user?.nickname || '');
  const [editedSignature, setEditedSignature] = useState(user?.signature || '');
  // 通知开关状态（按标题为键）
  const [toggles, setToggles] = useState<Record<string, boolean>>({
    告警通知: true,
    邮箱通知: false,
  });

  // 进入页面拉取资料、孩子列表与告警
  useEffect(() => {
    fetchProfile();
    fetchChildren();
    fetchAlerts();
  }, [fetchProfile, fetchChildren, fetchAlerts]);

  // 资料变化时同步昵称到编辑框
  useEffect(() => {
    if (parentProfile) setEditedNickname(parentProfile.nickname);
  }, [parentProfile]);

  /**
   * 保存资料：调用鉴权 store 更新昵称与签名
   */
  const handleSave = async () => {
    await updateProfile({ nickname: editedNickname, signature: editedSignature });
    toast.success('资料已更新');
    setIsEditing(false);
  };

  /**
   * 退出登录并跳转首页
   */
  const handleLogout = () => {
    logout();
    navigate('/');
  };

  /**
   * 切换某个通知开关
   * @param label - 设置项标题
   * @param currentOn - 当前是否开启
   */
  const toggleItem = (label: string, currentOn: boolean) => {
    const newValue = !currentOn;
    setToggles((prev) => ({ ...prev, [label]: newValue }));
    toast.info(newValue ? '已开启通知' : '已关闭通知');
  };

  // 展示用昵称：优先取家长资料，再取用户信息，兜底「家长」
  const displayName = parentProfile?.nickname || user?.nickname || '家长';
  // 展示用电话
  const phone = parentProfile?.phone || '未绑定';
  // 注册时间
  const createdAt = parentProfile?.createdAt || user?.createdAt;

  // 真实统计：绑定孩子数、待处理告警数、关注天数
  const childCount = children.length;
  const pendingAlertCount = emergencyAlerts.filter((a) => !a.confirmed).length;
  // 关注天数 = 当前时间 - 注册时间，至少为 1
  const followDays = createdAt
    ? Math.max(1, Math.ceil((Date.now() - new Date(createdAt).getTime()) / (1000 * 60 * 60 * 24)))
    : '--';

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-amber-50">
      <Header role="parent" />

      <main id="main" className="pt-20 pb-8 px-4 max-w-4xl mx-auto">
        {/* 个人信息卡片 */}
        <div className="bg-gradient-to-r from-accent-400 to-accent-600 rounded-3xl p-6 mb-6 text-white shadow-xl">
          <div className="flex items-center gap-6 flex-wrap">
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
              <User className="w-10 h-10" />
            </div>
            <div className="flex-1 min-w-0">
              {isEditing ? (
                <div className="space-y-2">
                  <input
                    type="text"
                    value={editedNickname}
                    onChange={(e) => setEditedNickname(e.target.value)}
                    className="bg-white/20 text-white border border-white/30 rounded-lg px-3 py-2 w-full max-w-xs"
                    placeholder="昵称"
                    aria-label="编辑昵称"
                  />
                  <input
                    type="text"
                    value={editedSignature}
                    onChange={(e) => setEditedSignature(e.target.value)}
                    className="bg-white/20 text-white border border-white/30 rounded-lg px-3 py-2 w-full max-w-xs"
                    placeholder="个性签名"
                    aria-label="编辑个性签名"
                  />
                </div>
              ) : (
                <div>
                  <h2 className="text-2xl font-bold">{displayName}</h2>
                  <p className="text-orange-100 mt-1 flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    {phone}
                  </p>
                  {user?.signature && (
                    <p className="text-orange-100 text-sm mt-1">{user.signature}</p>
                  )}
                </div>
              )}
              <div className="flex items-center gap-2 mt-3 flex-wrap">
                <span className="px-3 py-1 bg-white/20 rounded-full text-sm">家长</span>
                {createdAt && (
                  <span className="px-3 py-1 bg-white/20 rounded-full text-sm">
                    注册于 {new Date(createdAt).toLocaleDateString('zh-CN')}
                  </span>
                )}
              </div>
            </div>
            <button
              onClick={isEditing ? handleSave : () => setIsEditing(true)}
              aria-label={isEditing ? '保存' : '编辑'}
              className="p-3 bg-white/20 rounded-full hover:bg-white/30 transition-colors"
            >
              {isEditing ? <Check className="w-5 h-5" /> : <Edit3 className="w-5 h-5" />}
            </button>
          </div>
          {isUsingMockData && (
            <p className="text-orange-200 text-xs mt-3">（后端未连接，展示示例数据）</p>
          )}
        </div>

        {error && (
          <div className="mb-6 p-4 bg-danger-50 border border-danger-200 rounded-xl text-danger-600 text-sm flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            {error}
          </div>
        )}

        {isLoading && !parentProfile && (
          <div className="bg-white rounded-2xl p-8 shadow-lg text-center text-gray-400 mb-6">
            加载中...
          </div>
        )}

        {/* 绑定概览 */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-2xl p-5 shadow-lg text-center">
            <p className="text-3xl font-bold bg-gradient-to-r from-accent-400 to-accent-600 bg-clip-text text-transparent">
              {childCount}
            </p>
            <p className="text-sm text-gray-500 mt-1">绑定孩子</p>
          </div>
          <div className="bg-white rounded-2xl p-5 shadow-lg text-center">
            <p className="text-3xl font-bold bg-gradient-to-r from-accent-400 to-accent-600 bg-clip-text text-transparent">
              {pendingAlertCount}
            </p>
            <p className="text-sm text-gray-500 mt-1">待处理告警</p>
          </div>
          <div className="bg-white rounded-2xl p-5 shadow-lg text-center">
            <p className="text-3xl font-bold bg-gradient-to-r from-accent-400 to-accent-600 bg-clip-text text-transparent">
              {followDays}
            </p>
            <p className="text-sm text-gray-500 mt-1">关注天数</p>
          </div>
        </div>

        {/* 通知与隐私设置 */}
        <div className="bg-white rounded-3xl p-6 mb-6 shadow-lg">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Settings className="w-5 h-5 text-orange-500" />
            通知与隐私
          </h3>
          <div className="space-y-3">
            {settingsItems.map((item) => {
              const Icon = item.icon;
              const isToggle = item.label === '告警通知' || item.label === '邮箱通知';
              const isOn = toggles[item.label] ?? item.defaultOn ?? false;
              return (
                <div
                  key={item.label}
                  role={isToggle ? undefined : 'button'}
                  tabIndex={isToggle ? undefined : 0}
                  onClick={isToggle ? undefined : () => toast.info('功能开发中，敬请期待')}
                  onKeyDown={isToggle ? undefined : (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toast.info('功能开发中，敬请期待'); } }}
                  className={`w-full flex items-center gap-4 p-4 rounded-xl transition-colors ${isToggle ? 'hover:bg-orange-50' : 'hover:bg-orange-50 cursor-pointer'}`}
                >
                  <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-orange-600" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-medium text-gray-800">{item.label}</p>
                    <p className="text-sm text-gray-500">{item.description}</p>
                  </div>
                  {isToggle ? (
                    <button
                      role="switch"
                      aria-checked={isOn}
                      aria-label={item.label}
                      onClick={() => toggleItem(item.label, isOn)}
                      className={`relative w-12 h-6 rounded-full transition-colors flex-shrink-0 ${
                        isOn ? 'bg-accent-400' : 'bg-gray-300'
                      }`}
                    >
                      <span
                        className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform duration-fast ${
                          isOn ? 'translate-x-6' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  ) : (
                    <span className="text-gray-400">›</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* 下载 App 推荐 */}
        <div className="bg-white rounded-3xl p-6 mb-6 shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-[#F4A261] to-[#E76F51] rounded-2xl p-5 sm:p-6 text-white relative overflow-hidden">
            <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-white/10 rounded-full"></div>
            <div className="absolute right-12 top-4 w-16 h-16 bg-white/10 rounded-full"></div>
            <div className="relative flex flex-col sm:flex-row items-center gap-5">
              <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center shadow-lg flex-shrink-0">
                <Smartphone className="w-10 h-10 text-[#E76F51]" />
              </div>
              <div className="flex-1 text-center sm:text-left">
                <h3 className="text-xl font-bold flex items-center justify-center sm:justify-start gap-2">
                  <Download className="w-5 h-5" />
                  下载星屿 App
                </h3>
                <p className="text-orange-100 text-sm mt-1">
                  扫码下载移动端，实时关注孩子心理状态，接收紧急告警
                </p>
                <div className="flex flex-wrap gap-2 mt-3 justify-center sm:justify-start">
                  <span className="px-2.5 py-1 bg-white/20 rounded-full text-xs">孩子状态</span>
                  <span className="px-2.5 py-1 bg-white/20 rounded-full text-xs">紧急告警</span>
                  <span className="px-2.5 py-1 bg-white/20 rounded-full text-xs">心情记录</span>
                </div>
              </div>
              <div className="flex flex-col items-center flex-shrink-0">
                <div className="w-24 h-24 bg-white rounded-xl p-2 shadow-lg">
                  <svg viewBox="0 0 100 100" className="w-full h-full">
                    <rect width="100" height="100" fill="white" />
                    {Array.from({ length: 49 }).map((_, i) => {
                      const row = Math.floor(i / 7);
                      const col = i % 7;
                      const seed = (row * 7 + col * 13 + row * col) % 3;
                      if (seed === 0) {
                        return <rect key={i} x={col * 14 + 2} y={row * 14 + 2} width="10" height="10" fill="#1f2937" />;
                      }
                      return null;
                    })}
                    <rect x="2" y="2" width="20" height="20" fill="none" stroke="#1f2937" strokeWidth="4" />
                    <rect x="6" y="6" width="12" height="12" fill="#1f2937" />
                    <rect x="78" y="2" width="20" height="20" fill="none" stroke="#1f2937" strokeWidth="4" />
                    <rect x="82" y="6" width="12" height="12" fill="#1f2937" />
                    <rect x="2" y="78" width="20" height="20" fill="none" stroke="#1f2937" strokeWidth="4" />
                    <rect x="6" y="82" width="12" height="12" fill="#1f2937" />
                  </svg>
                </div>
                <p className="text-xs text-orange-100 mt-1.5 flex items-center gap-1">
                  <QrCode className="w-3 h-3" /> 扫码下载
                </p>
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={handleLogout}
          aria-label="退出登录"
          className="w-full py-4 bg-red-50 text-red-600 rounded-2xl font-bold hover:bg-red-100 transition-colors flex items-center justify-center gap-2"
        >
          <LogOut className="w-5 h-5" />
          退出登录
        </button>
      </main>
    </div>
  );
}
