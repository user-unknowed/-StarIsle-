/**
 * @file TeacherProfile.tsx
 * @description 教师端个人资料页：展示/编辑信息、班级统计、快捷菜单、权限配置、数据管理、设置与退出登录
 * @module web-frontend/pages/teacher
 */
import { useState } from 'react';
import { useAuthStore } from '../../store/authStore';
import { useClassroomStore } from '../../store/classroomStore';
import { Header } from '../../components/common/Header';
import { useToast } from '../../components/ui/Toast';
import { User, Settings, Bell, BookOpen, Calendar, Edit3, Check, LogOut, Mail, Phone, Globe, Shield, Users, Download, Upload } from 'lucide-react';

// 快捷菜单项：图标、标题、徽章数（可选）
const menuItems = [
  { icon: Bell, label: '通知中心', badge: 2 },
  { icon: BookOpen, label: '数据报告' },
  { icon: Calendar, label: '打卡统计' },
  { icon: Settings, label: '系统设置' },
];

// 设置项：图标、标题、描述
const settingsItems = [
  { icon: Bell, label: '消息通知', description: '接收系统通知和提醒' },
  { icon: Mail, label: '邮箱设置', description: '配置邮箱通知' },
  { icon: Globe, label: '语言设置', description: '简体中文' },
  { icon: Phone, label: '隐私设置', description: '管理数据隐私和权限' },
];

// 权限初始配置：班级管理、学生数据、数据导入导出、风险预警、专业咨询
const initialPermissions = [
  { id: 'class-management', name: '班级管理', description: '管理班级信息和学生名单', enabled: true },
  { id: 'student-data', name: '学生数据查看', description: '查看学生心情数据和风险评估', enabled: true },
  { id: 'data-io', name: '数据导入导出', description: '导入导出学生数据和报告', enabled: true },
  { id: 'risk-alert', name: '风险预警管理', description: '管理风险预警和关注名单', enabled: true },
  { id: 'consult', name: '专业咨询', description: '使用专业心理咨询助手', enabled: true },
];

/**
 * 教师端个人资料组件
 * @returns JSX 元素
 */
export default function TeacherProfile() {
  // 当前用户、退出登录、更新资料
  const user = useAuthStore((state) => state.user);
  const logout = useAuthStore((state) => state.logout);
  const updateProfile = useAuthStore((state) => state.updateProfile);
  // 班级统计（用于展示）
  const stats = useClassroomStore((state) => state.stats);
  const toast = useToast();

  // 是否处于资料编辑态
  const [isEditing, setIsEditing] = useState(false);
  // 编辑中的昵称与签名
  const [editedNickname, setEditedNickname] = useState(user?.nickname || '');
  const [editedSignature, setEditedSignature] = useState(user?.signature || '');
  // 权限列表
  const [permissions, setPermissions] = useState(initialPermissions);

  /**
   * 保存资料：调用鉴权 store 更新昵称与签名
   */
  const handleSave = async () => {
    await updateProfile({ nickname: editedNickname, signature: editedSignature });
    setIsEditing(false);
    toast.success('资料已更新');
  };

  /**
   * 切换某权限开关
   * @param id - 权限ID
   */
  const togglePermission = (id: string) => {
    setPermissions(prev => prev.map(p => p.id === id ? { ...p, enabled: !p.enabled } : p));
    toast.info('权限已更新（演示）');
  };

  /**
   * 未开发功能占位提示
   */
  const comingSoon = () => toast.info('功能开发中，敬请期待');

  // totalClasses 由 classroomStore 提供（跨文件依赖，类型尚未包含则安全降级到 '--'）
  const classCount = (stats as { totalClasses?: number } | null)?.totalClasses ?? '--';
  const studentCount = stats?.totalStudents ?? '--';

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-indigo-50">
      <Header role="teacher" />

      <main id="main" className="pt-20 pb-8 px-4 max-w-4xl mx-auto">
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl p-6 mb-8 text-white shadow-xl">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
              <User className="w-10 h-10" />
            </div>
            <div className="flex-1">
              {isEditing ? (
                <div>
                  <input
                    type="text"
                    value={editedNickname}
                    onChange={(e) => setEditedNickname(e.target.value)}
                    className="bg-white/20 text-white border border-white/30 rounded-lg px-3 py-2 mb-2 w-full"
                    placeholder="昵称"
                  />
                  <textarea
                    value={editedSignature}
                    onChange={(e) => setEditedSignature(e.target.value)}
                    className="bg-white/20 text-white border border-white/30 rounded-lg px-3 py-2 w-full"
                    placeholder="个性签名"
                    rows={2}
                  />
                </div>
              ) : (
                <div>
                  <h2 className="text-2xl font-bold">{user?.nickname}</h2>
                  <p className="text-indigo-200 mt-1">{user?.signature || '暂无个性签名'}</p>
                </div>
              )}
              <div className="flex items-center gap-2 mt-3">
                <span className="px-3 py-1 bg-white/20 rounded-full text-sm">教师</span>
                <span className="px-3 py-1 bg-white/20 rounded-full text-sm flex items-center gap-1">
                  <Shield className="w-4 h-4" />
                  专业权限
                </span>
              </div>
            </div>
            <button
              onClick={isEditing ? handleSave : () => setIsEditing(true)}
              aria-label={isEditing ? '保存' : '编辑'}
              className="p-3 bg-white/20 rounded-full hover:bg-white/30 transition-colors"
            >
              {isEditing ? <Check className="w-5 h-5" /> : <Edit3 className="w-5 h-5" />}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-2xl p-5 shadow-lg text-center">
            <p className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">{classCount}</p>
            <p className="text-sm text-gray-500 mt-1">管理班级</p>
          </div>
          <div className="bg-white rounded-2xl p-5 shadow-lg text-center">
            <p className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">{studentCount}</p>
            <p className="text-sm text-gray-500 mt-1">学生总数</p>
          </div>
          <div className="bg-white rounded-2xl p-5 shadow-lg text-center">
            <p className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">--</p>
            <p className="text-sm text-gray-500 mt-1">咨询次数</p>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-6 mb-8 shadow-lg">
          <h3 className="text-lg font-bold text-gray-800 mb-4">快捷菜单</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.label}
                  onClick={comingSoon}
                  aria-label={item.label}
                  className="flex flex-col items-center p-4 rounded-xl hover:bg-purple-50 transition-colors"
                >
                  <div className="relative">
                    <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-2">
                      <Icon className="w-6 h-6 text-purple-600" />
                    </div>
                    {item.badge && (
                      <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                        {item.badge}
                      </span>
                    )}
                  </div>
                  <span className="text-sm font-medium text-gray-700">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="bg-white rounded-3xl p-6 mb-8 shadow-lg">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Shield className="w-5 h-5 text-purple-600" />
            权限配置
          </h3>
          <div className="space-y-3">
            {permissions.map((item) => (
              <div key={item.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <div>
                  <p className="font-medium text-gray-800">{item.name}</p>
                  <p className="text-sm text-gray-500">{item.description}</p>
                </div>
                <button
                  role="switch"
                  aria-checked={item.enabled}
                  aria-label={`${item.name} 权限开关`}
                  onClick={() => togglePermission(item.id)}
                  className={`w-12 h-7 rounded-full transition-colors ${
                    item.enabled ? 'bg-purple-600' : 'bg-gray-300'
                  }`}
                >
                  <span
                    className={`block w-5 h-5 bg-white rounded-full transition-transform ${
                      item.enabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  ></span>
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-3xl p-6 mb-8 shadow-lg">
          <h3 className="text-lg font-bold text-gray-800 mb-4">数据管理</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button
              onClick={comingSoon}
              aria-label="导入数据"
              className="flex items-center gap-4 p-4 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors text-left"
            >
              <div className="w-12 h-12 bg-blue-200 rounded-xl flex items-center justify-center">
                <Upload className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-gray-800">导入数据</p>
                <p className="text-sm text-gray-500">支持Excel或CSV格式文件导入</p>
              </div>
            </button>
            <button
              onClick={comingSoon}
              aria-label="导出报告"
              className="flex items-center gap-4 p-4 bg-green-50 rounded-xl hover:bg-green-100 transition-colors text-left"
            >
              <div className="w-12 h-12 bg-green-200 rounded-xl flex items-center justify-center">
                <Download className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="font-medium text-gray-800">导出报告</p>
                <p className="text-sm text-gray-500">导出班级数据和分析报告</p>
              </div>
            </button>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-6 mb-8 shadow-lg">
          <h3 className="text-lg font-bold text-gray-800 mb-4">设置</h3>
          <div className="space-y-3">
            {settingsItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.label}
                  onClick={comingSoon}
                  aria-label={item.label}
                  className="w-full flex items-center gap-4 p-4 rounded-xl hover:bg-gray-50 transition-colors text-left"
                >
                  <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                    <Icon className="w-5 h-5 text-gray-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-800">{item.label}</p>
                    <p className="text-sm text-gray-500">{item.description}</p>
                  </div>
                  <span className="text-gray-400">›</span>
                </button>
              );
            })}
          </div>
        </div>

        <button
          onClick={() => {
            logout();
          }}
          aria-label="退出登录"
          className="w-full py-4 bg-red-50 text-red-600 rounded-2xl font-bold hover:bg-red-100 transition-colors flex items-center justify-center gap-2"
        >
          <LogOut className="w-5 h-5" />
          退出登录
        </button>
      </main>
    </div>
  );
}
